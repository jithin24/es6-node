module.exports = {
  method: 'POST',
  path: '/start',
  handler: require('../handlers/start')
};
