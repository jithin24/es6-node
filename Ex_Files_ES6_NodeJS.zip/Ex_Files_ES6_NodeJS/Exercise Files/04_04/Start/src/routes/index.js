module.exports = [
  require('./main'),
  require('./start'),
  require('./quotes'),
  require('./pizza'),
  require('./pizzas')
].concat(require('./static'));
