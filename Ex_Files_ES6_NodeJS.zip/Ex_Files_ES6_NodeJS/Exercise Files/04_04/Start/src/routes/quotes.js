module.exports = {
  method: 'GET',
  path: '/quotes',
  handler: require('../handlers/quotes')
};
