module.exports = {
  method: 'GET',
  path: '/pizzas',
  handler: require('../handlers/pizzas')
};
